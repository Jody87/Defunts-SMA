# Defunt-Sma
Installer la derniere version de NodeJs ('https://nodejs.org/en/')

Ouvrir le dossier du projet dans un terminal

Faire 'npm install' pour installer les dependances

Lancer le project avec la commancde 'node server.js'

La route <nom de domaine>/<mois>/<jour>

Mois: texte en français

Jour: Jour en chiffre

Exemple pour recuperer la liste des personnes du 13 juin

<nom de domaine>/juin/13
